Lower poly elf archer version (about 8k polygons compared to originally about 15k)

Textures unchanged and can be extracted from the original .blend, not sure if the normal-maps will still work correctly with the changes.

Based on elf mesh by "theclubber"
http://opengameart.org/content/rigged-textured-elven-archer

License CC-by-SA:
http://creativecommons.org/licenses/by-sa/3.0/
